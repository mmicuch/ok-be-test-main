package su.umb.prog3.demo.demo.persistence.Services;

import org.springframework.stereotype.Service;
import su.umb.prog3.demo.demo.persistence.entity.OsobaVakcina;
import su.umb.prog3.demo.demo.persistence.repos.OsobaVakcinaRepository;

import java.util.List;
import java.util.Optional;

@Service
public class OsobaVakcinaService {

    private final OsobaVakcinaRepository osobaVakcinaRepository;

    public OsobaVakcinaService(OsobaVakcinaRepository osobaVakcinaRepository) {
        this.osobaVakcinaRepository = osobaVakcinaRepository;
    }

    // Get all osoba_vakcina records
    public List<OsobaVakcina> getAllOsobaVakcina() {
        return osobaVakcinaRepository.findAll();
    }

    // Get osoba_vakcina by ID
    public Optional<OsobaVakcina> getOsobaVakcinaById(Long id) {
        return osobaVakcinaRepository.findById(id);
    }

    // Create a new osoba_vakcina record
    public OsobaVakcina createOsobaVakcina(OsobaVakcina osobaVakcina) {
        return osobaVakcinaRepository.save(osobaVakcina);
    }

    // Update an existing osoba_vakcina record
    public Optional<OsobaVakcina> updateOsobaVakcina(Long id, OsobaVakcina osobaVakcina) {
        if (osobaVakcinaRepository.existsById(id)) {
            osobaVakcina.setIdEntity(id);
            return Optional.of(osobaVakcinaRepository.save(osobaVakcina));
        } else {
            return Optional.empty();
        }
    }

    // Delete osoba_vakcina by ID
    public boolean deleteOsobaVakcina(Long id) {
        if (osobaVakcinaRepository.existsById(id)) {
            osobaVakcinaRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}