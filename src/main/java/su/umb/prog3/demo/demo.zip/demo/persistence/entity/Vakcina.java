package su.umb.prog3.demo.demo.persistence.entity;

import jakarta.persistence.*;
import su.umb.prog3.demo.demo.persistence.enums.TypVakciny;

import java.util.List;

@Entity
public class Vakcina {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nazov;
    private String vyrobca;

    @Enumerated(EnumType.STRING)
    private TypVakciny typ;

    @OneToMany(mappedBy = "vakcina", cascade = CascadeType.ALL)
    private List<OsobaVakcina> osoby;

    public Long getIdEntity() {
        return id;
    }

    public void setIdEntity(Long id) {
        this.id = id;
    }

    public String getNazovEntity() {
        return nazov;
    }

    public void setNazovEntity(String nazov) {
        this.nazov = nazov;
    }

    public String getVyrobcaEntity() {
        return vyrobca;
    }

    public void setVyrobcaEntity(String vyrobca) {
        this.vyrobca = vyrobca;
    }

    public TypVakciny getTypEntity() {
        return typ;
    }

    public void setTypEntity(TypVakciny typ) {
        this.typ = typ;
    }

    public List<OsobaVakcina> getOsobyEntity() {
        return osoby;
    }

    public void setOsobyEntity(List<OsobaVakcina> osoby) {
        this.osoby = osoby;
    }

    @Override
    public String toString() {
        return "Vakcina{" +
                "id=" + id +
                ", nazov='" + nazov + '\'' +
                ", vyrobca='" + vyrobca + '\'' +
                ", typ=" + typ +
                '}';
    }
}
