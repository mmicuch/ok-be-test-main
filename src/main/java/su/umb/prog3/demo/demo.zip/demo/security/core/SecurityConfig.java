package su.umb.prog3.demo.demo.security.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final DemoSecurityExceptionHandler securityExceptionHandler;

    public SecurityConfig(DemoSecurityExceptionHandler securityExceptionHandler) {
        this.securityExceptionHandler = securityExceptionHandler;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable());

        // Špecifikácia autorizačných pravidiel
        http.authorizeHttpRequests(auth ->
            auth.requestMatchers("/api/public/**").permitAll() // Verejné endpointy
                .requestMatchers("/api/admin/**").hasRole("ADMIN") // Len pre adminov
                .anyRequest().authenticated() // Všetko ostatné vyžaduje autentifikáciu
        );

        // Pridanie vlastného autentifikačného filtra
        http.addFilterBefore(demoAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);

        // Nastavenie handlera pre spracovanie výnimiek
        http.exceptionHandling(ex -> ex.authenticationEntryPoint(securityExceptionHandler));

        return http.build();
    }

    @Bean
    public DemoAuthenticationFilter demoAuthenticationFilter() {
        return new DemoAuthenticationFilter();
    }
}
