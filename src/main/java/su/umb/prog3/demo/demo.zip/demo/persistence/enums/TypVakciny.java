package su.umb.prog3.demo.demo.persistence.enums;

public enum TypVakciny {
    mRNA,
    vektorová,
    proteínová,
    iná
}
